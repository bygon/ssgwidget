/** Automatically generated file. DO NOT MODIFY */
package com.se.seadwidget;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}