package com.se.seadwidget;

public class Const {

	/* BroadCastReceiver Filter */
	public static final String ACTION_MENU   = "com.se.seadwidget.ACTION_MENU";
	public static final String ACTION_MENUAL = "com.se.seadwidget.ACTION_MENUAL";
	public static final String ACTION_ACCOUNT = "com.se.seadwidget.ACTION_ACCOUNT";
	public static final String ACTION_POINT = "com.se.seadwidget.ACTION_POINT";
	public static final String ACTION_LINK    = "com.se.seadwidget.ACTION_LINK";	
}
